@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header text-bold">
                    <strong>No Permission</strong>
                </div>
                <div class="card-block">
                   <h1 class="text-danger">
                        You don't have permission to access this page!
                   </h1>
                </div>
            </div>
        </div>
    </div>
@endsection
