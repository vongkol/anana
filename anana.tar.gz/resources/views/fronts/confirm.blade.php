@extends('layouts.message')
@section('content')
<div class="earning-dashboard">
    <section class="footer-contact-area section_padding_100 clearfix" id="contact">
        <div class="container">
            <h2 class="text-white">Sign Up Completion</h2>
        </div>
    </section>
    <section>
        <div class="container">
           <h3 class="text-blue">
               THANKS YOU FOR YOUR SIGN UP. <br><br>
               PLEASE CHECK YOUR EMAIL TO VERIFY YOUR LOGIN!
           </h3>
        </div>
        <p>&nbsp;</p>
        <hr>
        <p>&nbsp;</p>
    </section>
</div>
@endsection