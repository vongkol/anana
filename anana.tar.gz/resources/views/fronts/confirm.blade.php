@extends('layouts.page')
@section('content')
    <!-- ***** Contact Us Area Start ***** -->
    <section class="footer-contact-area section_padding_100 clearfix" id="contact">
        <div class="container">
            <h2 class="text-white">Sign Up Completion</h2>
        </div>
    </section>
    <section>
        <div class="container" style="margin-top: 54px">
           <h3 class="text-success">
               Thanks for your sign up. Please check your email to verify and complete the registration!
           </h3>
        </div>
        <p>&nbsp;</p>
        <hr>
        <p>&nbsp;</p>
    </section>

@endsection