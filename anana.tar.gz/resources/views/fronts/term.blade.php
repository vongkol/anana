@extends('layouts.page')
@section('content')
<div class="container" style="margin-top:150px">
    <h3>Terms and Conditions <a href="{{url('dashboard')}}" class="btn btn-success btn-sm">Back</a></h3>
    <p></p>
    <div class="row">
        <div class="col-sm-12">
            <p>
                terms and conditions ...
            </p>
        </div>
    </div> 
</div>
@stop