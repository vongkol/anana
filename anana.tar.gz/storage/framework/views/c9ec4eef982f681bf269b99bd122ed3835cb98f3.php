<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h3 class="page-header">
            <i class="fa fa-cube"></i> Block 
            <a href="<?php echo e(url('analee-admin/block/create')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i> New</a>
        </h3>
        <?php if(Session::has('sms')): ?>
            <div class="alert alert-success" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div>
                    <?php echo e(session('sms')); ?>

                </div>
            </div>
        <?php endif; ?>
        <table class="table table-condensed table-responsive">
            <thead>
                <tr>
                    <th>&numero;</th>
                    <th>Block Title</th>
                    <th>Total Token</th>
                    <th>Balance</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $pagex = @$_GET['page'];
                    if(!$pagex)
                    $pagex = 1;
                    $i = 18 * ($pagex - 1) + 1;
                ?>
                <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($r->title); ?></td>
                    <td><?php echo e($r->total_token); ?></td>
                    <td><?php echo e($r->balance); ?></td>
                    <td>
                        <a href="<?php echo e(url('analee-admin/block/delete?id='.$r->id.'&page='.@$_GET['page'])); ?>" class="btn btn-danger btn-xs" 
                            title="Delete" onclick="return confirm('You want to delete?')">
                        <i class="fa fa-trash"></i></a>&nbsp;&nbsp;
                        <a href="<?php echo e(url('analee-admin/block/edit/'.$r->id)); ?>" 
                            class="btn btn-success btn-xs" title="Edit"><i class="fa fa-pencil"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($blocks->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>