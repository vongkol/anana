<?php $__env->startSection('content'); ?>
   <div class="container">
    <div class="earning-dashboard">
    <h3>
    <span class="text-warning">ACCOUNT SECURITY PIN</span> &nbsp;
         <a href="<?php echo e(url('member/account/'.$id)); ?>" class="btn btn-success btn-alc"><i class="fa fa-arrow-left"></i> Back</a>
         <hr class="hr-alc">
    </h3>
   <br>
    <div class="row">
        <div class="col-sm-12">
            <div class="bg-light alc-box font-weight-bold shadow-alc mb-5 border-radius-15">
                <h4 class="card-header">CHANGE PASSWORD</h4>
            <?php if(Session::has('sms')): ?>
                <div class="alert alert-success" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <div>
                        <?php echo e(session('sms')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(Session::has('sms1')): ?>
                <div class="alert alert-danger" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <div>
                        <?php echo e(session('sms1')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="p-3 font-size-16 text-blue">
                <form action="<?php echo e(url('member/change-pin/save')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group row">
                        <label class="col-md-3">Old Security PIN <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="password" name="old_pin" required class="form-control border-radius-22" value="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3">New Security PIN <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="password" name="security_pin" required class="form-control border-radius-22" value="<?php echo e(old('security_pin')); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-md-3">Confirm New Security PIN <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <input type="password" name="cpin" required class="form-control border-radius-22" value="<?php echo e(old('cpin')); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-sm-3">&nbsp;</label>
                        <div class="col-sm-9">
                            <button class="btn btn-warning btn-alc">Change</button>
                        </div>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>