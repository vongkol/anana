<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h3 class="page-header">
            <div class="row">
                <div class="col-sm-6">
                    <i class="fa fa-user"></i> Members 
                </div>
                <div class="col-sm-6">
                    <form action="#">
                        <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                    </form>
                </div>
            </div>
            
        </h3>
      
        <?php if(Session::has('sms')): ?>
            <div class="alert alert-success" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div>
                    <?php echo e(session('sms')); ?>

                </div>
            </div>
        <?php endif; ?>
        <table class="table table-condensed table-responsive">
            <thead>
                <tr>
                    <th>&numero;</th>
                    <th>Full Name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Country</th>
                    <th>Sponsor ID</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $pagex = @$_GET['page'];
                    if(!$pagex)
                    $pagex = 1;
                    $i = 25 * ($pagex - 1) + 1;
                ?>
                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td>
                        <a href="<?php echo e(url('analee-admin/member/detail/'.$m->id)); ?>" class="text-primary"><?php echo e($m->full_name); ?></a>    
                    </td>
                    <td><?php echo e($m->username); ?></td>
                    <td><?php echo e($m->email); ?></td>
                    <td><?php echo e($m->phone); ?></td>
                    <td><?php echo e($m->country); ?></td>
                    <td><?php echo e($m->sponsor_id); ?></td>
                    <td>
                        <a href="<?php echo e(url('analee-admin/member/detail/'.$m->id)); ?>" 
                                class="btn btn-success btn-xs" title="View"><i class="fa fa-eye"></i></a>&nbsp;&nbsp;
                        <a href="<?php echo e(url('analee-admin/member/delete/'.$m->id.'&page='.@$_GET['page'])); ?>" class="btn btn-danger btn-xs" 
                            title="Delete" onclick="return confirm('You want to delete?')">
                        <i class="fa fa-trash"></i></a>
                       
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <p>
            Total Members: <?php echo e($total); ?>

        </p>
        <?php echo e($members->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>