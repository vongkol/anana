<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="container-page">
        <nav aria-label="breadcrumb">
            
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Investment Package</li>
            </ol>
            <h4 class="pull-right page-title mb-title text-warning">
                INVESTMENT PACKAGE
            </h4>
        </nav>
    </div>
</div>
<div class="bg-investment">
<div class="container">
    <div class="pricing row">
    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 my-2 px-2 ">
            <div class="card card-pricing shadow text-center">
                <span class="h6 w-60 investment-name mx-auto px-4 py-2  rounded-bottom bg-warning text-dark shadow-sm"><strong><i class="fa fa-diamond" aria-hidden="true"></i> <?php echo e($p->name); ?></strong></span>
                <div class="bg-transparent card-header px-1 border-0">
                    <h1 class="h1 font-weight-normal text-danger text-center mb-0" data-pricing-value="15">$<span class="price"><?php echo e($p->price); ?></span><span class="h6 text-dark ml-2">/ <?php echo e($p->duration); ?> days</span></h1>
                </div>
                <div class="card-body pt-0">
                    <ul class="list-unstyled mb-4">
                        <h5>Payout: <?php echo e($p->monthly_payout); ?>%</h5>
                    </ul>
                    <a href="<?php echo e(url('sign-up')); ?>" class="btn btn-dark shadow rounded btn-blog mb-3"><img src="<?php echo e(asset('images/invesment.png')); ?>" alt="" 
                     width="30"> <strong> Invest Now</strong></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>