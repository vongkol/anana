<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h3 class="page-header">
            <i class="fa fa-upload"></i> Package 
            <a href="<?php echo e(url('analee-admin/package/create')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-plus"></i> New</a>
        </h3>
        <?php if(Session::has('sms')): ?>
            <div class="alert alert-success" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div>
                    <?php echo e(session('sms')); ?>

                </div>
            </div>
        <?php endif; ?>
        <table class="table table-condensed table-responsive">
            <thead>
                <tr>
                    <th>&numero;</th>
                    <th>Package Name</th>
                    <th>Price</th>
                    <th>Monthly Payout</th>
                    <th>Duration</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $pagex = @$_GET['page'];
                    if(!$pagex)
                    $pagex = 1;
                    $i = 18 * ($pagex - 1) + 1;
                ?>
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($r->name); ?></td>
                    <td><?php echo e($r->price); ?> $</td>
                    <td><?php echo e($r->monthly_payout); ?> %</td>
                    <td><?php echo e($r->duration); ?></td>
                    <td>
                        <a href="<?php echo e(url('analee-admin/package/delete?id='.$r->id.'&page='.@$_GET['page'])); ?>" class="btn btn-danger btn-xs" 
                            title="Delete" onclick="return confirm('You want to delete?')">
                        <i class="fa fa-trash"></i></a>&nbsp;&nbsp;
                        <a href="<?php echo e(url('analee-admin/package/edit/'.$r->id)); ?>" 
                            class="btn btn-success btn-xs" title="Edit"><i class="fa fa-pencil"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($packages->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>