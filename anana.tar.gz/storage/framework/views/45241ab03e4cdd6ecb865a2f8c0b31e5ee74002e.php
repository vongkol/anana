<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('tree/Treant.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('tree/examples/basic-example/basic-example.css')); ?>">
<div class="container">
    <div class="earning-dashboard">
        <h3>
        <span class="text-warning" style="font-size: 1.75rem;font-weight:600;">
            NETWORK
        </span> &nbsp;
            <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-success btn-alc"> <i class="fa fa-arrow-left"></i>  Back</a>
            <hr class="hr-alc">
        </h3>
        <br>
        <div class="row">
            <div class="col-sm-12">
                <div class="chart" id="tree"></div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('tree/vendor/raphael.js')); ?>"></script>
<script src="<?php echo e(asset('tree/Treant.js')); ?>"></script>
    
<script>

    var config = {
        container: "#tree",
        
        connectors: {
            type: 'step'
        },
        node: {
            HTMLclass: 'nodeExample1'
        }
    };


    // grand pa node
    var papa = {
         text: {
            name: "<?php echo e($m->username); ?>"
               
        },
        image: "<?php echo e(asset('images/icon.png')); ?>"
    };
    // initial config
    chart_config = [
        config,
        papa
    ];

    // first gen 1 node
    <?php
        $gen1 = DB::table('members')->where('sponsor_id', $m->username)->get();
    ?>
    <?php $__currentLoopData = $gen1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        var gen1 = {
           parent: papa,
           text: {
                name: "<?php echo e($g1->username); ?>"
           },
           image: "<?php echo e(asset('images/icon.png')); ?>"
        };
        // push the gen1 to array
        chart_config.push(gen1);
        // find the gen2
        <?php $gen2 = DB::table('members')->where('sponsor_id', $g1->username)->get(); ?>
        <?php $__currentLoopData = $gen2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            var gen2 = {
                parent: gen1,
                text: {
                    name: "<?php echo e($g2->username); ?>"
                },
                image: "<?php echo e(asset('images/icon.png')); ?>"
            };
            chart_config.push(gen2);
            // find the gen3
            <?php $gen3 = DB::table('members')->where('sponsor_id', $g2->username)->get(); ?>
            <?php $__currentLoopData = $gen3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                var gen3 = {
                    parent: gen2,
                    text: {
                        name: "<?php echo e($g3->username); ?>"
                    },
                    image: "<?php echo e(asset('images/icon.png')); ?>"
                };
                chart_config.push(gen3);
                // find the gen4
                <?php $gen4 = DB::table('members')->where('sponsor_id', $g3->username)->get(); ?>
                <?php $__currentLoopData = $gen4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    var gen4 = {
                        parent: gen3,
                        text: {
                            name: "<?php echo e($g4->username); ?>"
                        },
                        image: "<?php echo e(asset('images/icon.png')); ?>"
                    };
                    chart_config.push(gen4);
                    // find the gen 5
                    <?php $gen5 = DB::table('members')->where('sponsor_id', $g4->username)->get(); ?>
                    <?php $__currentLoopData = $gen5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        var gen5 = {
                            parent: gen4,
                            text: {
                                name: "<?php echo e($g5->username); ?>"
                            },
                            image: "<?php echo e(asset('images/icon.png')); ?>"
                        };
                        chart_config.push(gen5);
                        // find the gen 6
                        <?php $gen6 = DB::table('members')->where('sponsor_id', $g5->username)->get(); ?>
                        <?php $__currentLoopData = $gen6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            var gen6 = {
                                parent: gen5,
                                text: {
                                    name: "<?php echo e($g6->username); ?>"
                                },
                                image: "<?php echo e(asset('images/icon.png')); ?>"
                            };
                            chart_config.push(gen6);
                         
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        new Treant( chart_config );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>