<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="earning-dashboard">
        <h3>
        <span class="text-warning">TRANSACTIONS</span> &nbsp;
        <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-success btn-alc"><i class="fa fa-arrow-left" aria-hidden="true"></i>  Back</a>
        <hr class="hr-alc">
    </h3>
        <div class="row">
            <div class="col-sm-12">
            <div class="bg-light alc-box text-center  shadow-alc mb-5 border-radius-15">
                <h4 class="card-header">TRANSACTIONS HISTORY</h4>
                <div class="p-3">
                <table class="table table-sm table-bordered text-blue">
                    <thead>
                        <tr>
                            <th>AMOUNT</th>
                            <th>DESCRIPTION</th>
                            <th>DATE</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td> <p></p>$ 1000</td>
                            <td> <p></p>WALLET DESCRIPTION</td>
                            <td> <p></p>2018-28-11</td>
                            <td> <p></p>
                                PENDING
                            </td>
                        </tr>
                        <tr>
                            <td>$ 1000</td>
                            <td>WALLET DESCRIPTION</td>
                            <td>2018-28-11</td>
                            <td>
                                PENDING
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div>
            </div>
        </div><br>
        <!-- <div class="row">
            <div class="col-sm-12">
                <strong class="text-warning">WITHDRAWAL HISTORY</strong>
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>DATE</th>
                            <th>AMOUNT</th>
                            <th>STATUS</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($p->id); ?></td>
                                <td><?php echo e($p->request_date); ?></td>
                                <td><?php echo e($p->amount); ?> $</td>
                                <td>
                                    <?php if($p->status==0): ?>
                                        pending
                                    <?php else: ?>
                                        approved
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        
        </div>
        <p></p>
        <div class="row">
            <div class="col-sm-12">
                <strong class="text-warning">TRANSFTER HISTORY</strong>
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>DATE</th>
                            <th>AMOUNT</th>
                            <th>SENT</th>
                            <th>RECIEVED</th>
                            <th>DESCRIPTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($t->id); ?></td>
                                <td><?php echo e($t->transaction_date); ?></td>
                                <td><?php echo e($t->amount); ?> $</td>
                                <td><?php echo e($t->account_name); ?></td>
                                <td></td>
                                <td><?php echo e($t->note); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $trans1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($t->id); ?></td>
                                <td><?php echo e($t->transaction_date); ?></td>
                                <td><?php echo e($t->amount); ?> $</td>
                                <td></td>
                                <td><?php echo e($t->account_name); ?></td>
                                <td><?php echo e($t->note); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div> -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>