<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h3 class="page-header">
            <i class="fa fa-upload"></i> Payment Request 
        </h3>
       
        <table class="table table-condensed table-responsive">
            <thead>
                <tr>
                    <th>&numero;</th>
                    <th>Account Name</th>
                    <th>Email</th>
                    <th>Request Amount</th>
                    <th>Request Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $pagex = @$_GET['page'];
                    if(!$pagex)
                    $pagex = 1;
                    $i = 22 * ($pagex - 1) + 1;
                ?>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($r->username); ?></td>
                    <td><?php echo e($r->email); ?></td>
                    <td>$ <?php echo e($r->amount); ?></td>
                    <td><?php echo e($r->request_date); ?></td>
                    <td>
                        <?php if($r->status==1): ?>
                            Approved
                        <?php else: ?>
                            Pending
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($r->status==0): ?>
                            <a href="<?php echo e(url('analee-admin/member/payment/approve')); ?>" class="btn btn-success btn-xs" 
                            title="Approve" onclick="return confirm('You want to approve this?')">
                                Approve
                            </a>
                       
                        <?php endif; ?>
                        
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($payments->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>