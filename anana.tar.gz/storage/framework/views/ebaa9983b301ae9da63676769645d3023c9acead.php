
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <h3 class="page-header">
                <i class="fa fa-key"></i> Permission For [<?php echo e($role->name); ?>]
                <a href="<?php echo e(url('analee-admin/role/')); ?>" class="btn btn-primary btn-xs"><i class="fa fa-arrow-left"></i> Back</a>
            </h3>
            <div class="card">
                <div class="card-block">
                    <?php echo e(csrf_field()); ?>

                    <table class="table table-condensed table-responsive">
                        <thead>
                        <tr>
                            <th>&numero;</th>
                            <th>Name</th>
                            <th>View</th>
                            <th>Insert</th>
                            <th>Update</th>
                            <th>Delete</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $per_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr role-id="<?php echo e($role_id); ?>" permission-id="<?php echo e($per->permission_id); ?>" id="<?php echo e($per->id==''?'0':$per->id); ?>">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($per->name); ?></td>
                                <td>
                                    <label class="switch switch-3d switch-primary">
                                        <input type='checkbox' value="<?php echo e($per->list?'1':'0'); ?>" <?php echo e($per->list==1?'checked':''); ?> onchange="save(this)" class="switch-input">
                                        <span class="switch-label"></span>
                                        <span class="switch-handle"></span>
                                    </label>

                                </td>
                                <td>
                                    <label class="switch switch-3d switch-primary">
                                        <input type='checkbox' value="<?php echo e($per->insert?'1':'0'); ?>" <?php echo e($per->insert==1?'checked':''); ?> onchange="save(this)" class="switch-input">
                                        <span class="switch-label"></span>
                                        <span class="switch-handle"></span>
                                    </label>

                                </td>
                                <td>
                                    <label class="switch switch-3d switch-primary">
                                        <input type='checkbox' value="<?php echo e($per->update?'1':'0'); ?>" <?php echo e($per->update==1?'checked':''); ?> onchange="save(this)" class="switch-input">
                                        <span class="switch-label"></span>
                                        <span class="switch-handle"></span>
                                    </label>

                                </td>
                                <td>
                                    <label class="switch switch-3d switch-primary">
                                        <input type='checkbox' value="<?php echo e($per->delete?'1':'0'); ?>" <?php echo e($per->delete==1?'checked':''); ?> onchange="save(this)" class="switch-input">
                                        <span class="switch-label"></span>
                                        <span class="switch-handle"></span>
                                    </label>

                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--/.col-->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    
    <script src="<?php echo e(asset('js/role_permission.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>