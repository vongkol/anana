<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h3 class="page-header">
            <i class="fa fa-upload"></i> Member Transfer Transaction
        </h3>
       
        <table class="table table-condensed table-responsive">
            <thead>
                <tr>
                    <th>&numero;</th>
                    <th>From Username</th>
                    <th>To Username</th>
                    <th>Amount</th>
                    <th>Transfer Date</th>
                    <th>To Wallet</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $pagex = @$_GET['page'];
                    if(!$pagex)
                    $pagex = 1;
                    $i = 22 * ($pagex - 1) + 1;
                ?>
                <?php $__currentLoopData = $trans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($r->username); ?></td>
                    <td><?php echo e($r->account_name); ?></td>
                    <td>$ <?php echo e($r->amount); ?></td>
                    <td><?php echo e($r->transaction_date); ?></td>
                   
                    <td><?php echo e($r->to_wallet); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo e($trans->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>