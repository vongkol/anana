<?php $__env->startSection('content'); ?>
   <div class="container">
    <div class="earning-dashboard">
    <h3>
    <span class="text-warning">MY ACCOUNT</span> / <span class="text-warning">ACCOUNT PASSWORD</span> &nbsp;
         <a href="<?php echo e(url('member/account/'.$id)); ?>" class="btn btn-success btn-alc"><i class="fa fa-arrow-left"></i> Back</a>
         <hr class="hr-alc">
    </h3>
    <br>
    <div class="row">
        <div class="col-sm-12">
            <div class="bg-light font-weight-bold shadow-alc p-3 border-radius-15">
                <h4>CHANGE PASSWORD</h4>
                <hr class="hr-alc">
            <?php if(Session::has('sms')): ?>
                <div class="alert alert-success" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <div>
                        <?php echo e(session('sms')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(Session::has('sms1')): ?>
                <div class="alert alert-danger" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <div>
                        <?php echo e(session('sms1')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(url('member/change-password/save')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group row">
                <h5 class="col-md-3">Old Password <span class="text-danger">*</span></h5>
                    <div class="col-sm-9">
                        <input type="password" name="old_password" required class="form-control border-radius-22" value="">
                    </div>
                </div>
                <div class="form-group row">
                    <h5 class="col-md-3">New Password <span class="text-danger">*</span></h5>
                    <div class="col-sm-9">
                        <input type="password" name="password" required class="form-control border-radius-22" value="<?php echo e(old('password')); ?>">
                    </div>
                </div>
                 <div class="form-group row">
                     <h5 class="col-md-3">Confirm Password <span class="text-danger">*</span></h5>
                    <div class="col-sm-9">
                        <input type="password" name="cpassword" required class="form-control border-radius-22" value="<?php echo e(old('cpass')); ?>">
                    </div>
                </div>
                 <div class="form-group row">
                    <label for="" class="col-sm-3">&nbsp;</label>
                    <div class="col-sm-9">
                        <button class="btn btn-primary btn-alc">Change</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>