<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        <h3 class="page-header">
            <div class="row">
                <div class="col-sm-5">
                    <i class="fa fa-user"></i> Member Detail 
                    <a href="<?php echo e(url('analee-admin/member')); ?>" class="btn btn-success btn-xs"><i class="fa fa-arrow-left"></i> Back</a>
                </div>
                <div class="col-sm-7">
                    <form action="#">
                        <input type="text" placeholder="search...">
                        <button>Search</button>
                    </form>
                </div>
            </div>
            
        </h3>
    </div>
</div>
<div class="row">
    <div class="col-sm-5">
       <h4>Profile Detail</h4>
        <table class="table table-sm">
            <tr>
                <td>Sponsor ID</td>
                <th>: <?php echo e($member->sponsor_id); ?></th>
            </tr>
            <tr>
                <td>Full Name</td>
                <th>: <?php echo e($member->full_name); ?></th>
            </tr>
            <tr>
                <td>Username</td>
                <th>: <?php echo e($member->username); ?></th>
            </tr>
            <tr>
                <td>Email</td>
                <th>: <?php echo e($member->email); ?></th>
            </tr>
            <tr>
                <td>Phone</td>
                <th>: <?php echo e($member->phone); ?></th>
            </tr>
            <tr>
                <td>Country</td>
                <th>: <?php echo e($member->country); ?></th>
            </tr>
            <tr>
                <td colspan="2">
                    <p><strong class="text-danger">ALC Address:</strong></p>
                    <p><?php echo e($member->anc_address); ?></p>
                </td>
            </tr>
             <tr>
                <td>Sale Volume</td>
                <td>
                    : $ <?php echo e($member->sale_volume); ?>

                </td>
            </tr>
            <tr>
                <td>Sale Bonus</td>
                <td>
                    : $ <?php echo e($member->sale_bonus); ?>

                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <a href="<?php echo e(url('analee-admin/member/reset-password/'.$member->id)); ?>" class="btn btn-sm btn-primary">Reset Password</a>
                    <a href="<?php echo e(url('analee-admin/member/reset-security-pin/'.$member->id)); ?>" class="btn btn-sm btn-warning">Reset Security Pin</a>
                    <a href="<?php echo e(url('analee-admin/member/delete/'.$member->id)); ?>" onclick="return confirm('You want to delete?')" class="btn btn-danger btn-sm">Delete</a> 
                    <a href="<?php echo e(url('analee-admin/member/credit/'.$member->id)); ?>" class="btn btn-success btn-sm">Add Credit</a> 
                    <a href="<?php echo e(url('analee-admin/member/volume/'. $member->id)); ?>" class="btn btn-primary btn-sm">Edit Sale Volume</a>
                </td>
            </tr>
           
        </table>
       
    </div>
    <div class="col-sm-1"></div>
    <div class="col-sm-4">
        <h4>Member Wallet</h4>
        <table class="table table-sm">
            <tr>
                <td>
                    Cash Wallet
                </td>
                <td>
                    : $ <?php echo e(\App\Http\Controllers\Helper::encryptor('decrypt', $member->cash_wallet)); ?>

                </td>
            </tr>
            <tr>
                <td>
                    Register Wallet
                </td>
                <td>
                    : $ <?php echo e(\App\Http\Controllers\Helper::encryptor('decrypt', $member->register_wallet)); ?>

                </td>
            </tr>
            <tr>
                <td>
                    Buy Back Wallet
                </td>
                <td>
                    : $ <?php echo e(\App\Http\Controllers\Helper::encryptor('decrypt', $member->token_wallet)); ?>

                </td>
            </tr>
            
        </table>
            <h4 class="text-danger">Bank Account</h4>
            <?php if($bank!=null): ?>
            <table class="table table-sm">
                <tr>
                    <td>
                        Bank Name
                    </td>
                    <td>
                        : <?php echo e($bank->bank_name); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        Bank Branch Name
                    </td>
                    <td>
                        : <?php echo e($bank->branch_name); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        Swift Code
                    </td>
                    <td>
                        : <?php echo e($bank->swift_code); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        Bank Address
                    </td>
                    <td>
                        : <?php echo e($bank->address); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        Full Name
                    </td>
                    <td>
                        : <?php echo e($bank->full_name); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        Account Number
                    </td>
                    <td>
                        : <?php echo e($bank->account_no); ?>

                    </td>
                </tr>
            </table>
            <?php else: ?>
                <p>No bank information!</p>
            <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <h3>Investment</h3>
        <?php if($investment==null): ?>
            <p class="text-danger">This member does not have an investment yet!</p>
        <?php else: ?>
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th>Package Name</th>
                        <th>Price</th>
                        <th>Pay Rate</th>
                        <th>Duration</th>
                        <th>Invest Date</th>
                        <th>Expired On</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($investment->name); ?></td>
                        <td><?php echo e($investment->price); ?> $</td>
                        <td><?php echo e($investment->monthly_payout); ?>%</td>
                        <td><?php echo e($investment->duration); ?> days</td>
                        <td><?php echo e($investment->order_date); ?></td>
                        <td><?php echo e($investment->expired_on); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>